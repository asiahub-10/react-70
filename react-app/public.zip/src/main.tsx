import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
// import { Button as Btn } from './Button.tsx'
import Counter from './Count.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Counter />
    <App />
  </StrictMode>,
)
